
# import
from network_graph import network_graph
from network_graph.datasets import load_got

# load the data
edge_df, node_df = load_got.load_got()

# define vis options
vis_opts = {'height': '600px', # change height
            'interaction':{'hover': True}, # turn on-off the hover 
            'physics':{'stabilization':{'iterations': 100}}} # define the convergence iteration of network

# init Jaal and run server (with opts)
# Jaal(edge_df, node_df).plot(vis_opts=vis_opts)

# init Jaal and run server (with gunicorn)
app = network_graph.network_graph(edge_df, node_df).plot(directed=True)
server = app.server