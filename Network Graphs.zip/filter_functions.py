

def _callback_filter_nodes(self, graph_data, filter_nodes_text):
	"""Filter the nodes based on the Python query syntax
	"""
	self.filtered_data = self.data.copy()
	node_df = pd.DataFrame(self.filtered_data['nodes'])
	try:
		node_list = node_df.query(filter_nodes_text)['id'].tolist()
		nodes = []
		for node in self.filtered_data['nodes']:
			if node['id'] in node_list:
				nodes.append(node)
		self.filtered_data['nodes'] = nodes
		graph_data = self.filtered_data
	except:
		graph_data = self.data
		print("wrong node filter query!!")
	return graph_data

def _callback_filter_edges(self, graph_data, filter_edges_text):
	"""Filter the edges based on the Python query syntax
	"""
	self.filtered_data = self.data.copy()
	edges_df = pd.DataFrame(self.filtered_data['edges'])
	node_df = pd.DataFrame(self.filtered_data['nodes'])
	try:
		edges_list = edges_df.query(filter_edges_text)['id'].tolist()
		edges = []
		node_list = list(set(edges_df.query(filter_edges_text)['from'].tolist() + edges_df.query(filter_edges_text)['to'].tolist()))
		nodes = []
		for edge in self.filtered_data['edges']:
			if edge['id'] in edges_list:
				edges.append(edge)
		self.filtered_data['edges'] = edges
		for node in self.filtered_data['nodes']:
			if node['id'] in node_list:
				nodes.append(node)
		self.filtered_data['nodes'] = nodes
		graph_data = self.filtered_data
	except:
		graph_data = self.data
		print("wrong edge filter query!!")
	return graph_data